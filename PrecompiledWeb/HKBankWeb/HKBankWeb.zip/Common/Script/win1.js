﻿function myUnload()
{
    alert("1");
}